### Hexlet tests and linter status:
[![Actions Status](https://github.com/erzhan12/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/erzhan12/python-project-49/actions)

### Codeclimate Maintainability
[![Maintainability](https://api.codeclimate.com/v1/badges/dae84d8c8681bb6e613b/maintainability)](https://codeclimate.com/github/erzhan12/python-project-49/maintainability)
