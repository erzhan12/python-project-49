#!/usr/bin/env python3
import prompt
import brain_games.cli
def main():
  brain_games.cli.welcome_user()


if __name__ == "__main__":
  main()